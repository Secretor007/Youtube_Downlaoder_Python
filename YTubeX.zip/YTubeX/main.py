import tkinter as tk
from tkinter import Button,messagebox
from PIL import ImageTk, Image, ImageSequence
from pytube import YouTube
from moviepy.editor import VideoFileClip, AudioFileClip
import requests
from io import BytesIO
import threading
import re
from pathlib import Path
import os
from tkinter import scrolledtext
import pygame

BG = "#FFF9D0"
selected_resolution = None
video_streams = []
streams_list = []
audio_streams = []
qualities = []
resolutions = []
widgets_created = []
yt = None


def paste_text():
    link_entry.delete(0, 'end')
    link_entry.insert('end', window.clipboard_get())

def get_info():
    global yt
    yt = YouTube(link_entry.get())

    thumb_img_link = yt.thumbnail_url
    response = requests.get(thumb_img_link)
    img_data = response.content
    img = Image.open(BytesIO(img_data))
    img = img.resize((150, 100))
    img = ImageTk.PhotoImage(img)

    canvas.itemconfig(panel_image, image=img)
    canvas.image = img

    canvas.itemconfig(tagOrId=canvas_text, text=f"{yt.title}")
    canvas.itemconfig(tagOrId=author_text, text=f"{yt.author}")
    canvas.coords(panel_image, 270, 140)
    canvas.coords(author_text, 270, 207)
    canvas.coords(canvas_text, 270, 60)

def get_info_thread():
    if len(link_entry.get())==0:
        search_is_empty()
    else:
        threading.Thread(target=get_info).start()
def video_download_thread():
    threading.Thread(target=video_download).start()
def audio_download_thread():
    threading.Thread(target=audio_download).start()

def select_type(type):
    global selected_type
    selected_type = str(type)
    if selected_type in resolutions:
        quality = qualities[-1]
        for stream in video_streams:
            if selected_type in stream:
                pattern = r'\"([^\"]*)\"'
                match_p = re.search(pattern, stream)
                if match_p:
                    threading.Thread(target=downloader, args=(int(match_p.group(1)), int(quality))).start()
    elif selected_type in qualities:
        for stream in audio_streams:
            pattern = r'\"([^\"]*)\"'
            if selected_type in stream:
                match_p = re.search(pattern, stream)
                if match_p:
                    folder_path = Path('songs')
                    folder_path.mkdir(parents=True, exist_ok=True)
                    stream = yt.streams.get_by_itag(match_p.group(1))
                    output_text.delete(1.0, tk.END)
                    output_text.insert(tk.END, "Downloading...\n")
                    stream.download(f"songs/{selected_type}")
                    output_text.insert(tk.END, "Download completed successfully!\n")
                    tuturu()
                    play_sound()
                    break

def video_download():
    clear_widgets()
    if yt is None:
        return
    quality_label = tk.Label(text="Choose Quality", bg=BG, fg="coral", font=("Times 20 italic bold", 20))
    quality_label.grid(row=4, column=1)
    widgets_created.append(quality_label)

    streams = yt.streams.filter(adaptive=True)
    video_streams.clear()
    streams_list.clear()
    audio_streams.clear()
    qualities.clear()
    resolutions.clear()

    for stream in streams:
        x = str(stream).replace("<", "(").replace(">", ")")
        streams_list.append(x)

    for stream in streams_list:
        if "audio/webm" in stream:
            audio_streams.append(stream)
    pattern_1 = r'\"([^\"]*)\"'
    for stream in audio_streams:
        match_1 = re.search(pattern_1, stream)
        if match_1:
            qualities.append(match_1.group(1))

    for stream in streams_list:
        if "vp9" in stream:
            video_streams.append(stream)
    pattern = r'res="(\d+p)"'

    for stream in video_streams:
        match = re.search(pattern, stream)
        if match:
            resolutions.append(match.group(1))
    gif_path = "video-ezgif.com-resize.gif"
    gif = Image.open(gif_path)
    frames = [ImageTk.PhotoImage(frame.copy()) for frame in ImageSequence.Iterator(gif)]

    for i, resolution in enumerate(resolutions):
        video_quality_btn = tk.Label(bg=BG)
        video_quality_btn.grid(row=5 + i*2, column=0, padx=10, pady=5)
        widgets_created.append(video_quality_btn)

        def animate(btn, frame_index=0):
            frame_index = (frame_index + 1) % len(frames)
            btn.config(image=frames[frame_index])
            btn.after(100, animate, btn, frame_index)

        animate(video_quality_btn)

        video_quality_label = tk.Label(text=f"Download {resolutions[i]}", bg=BG, fg="red", font=("Times 20 italic bold", 10))
        video_quality_label.grid(row=5 + i*2, column=1, padx=10, pady=5)
        widgets_created.append(video_quality_label)
        video_quality_btn.bind("<Button-1>", lambda event, res=resolution: select_type(res))

    for i, resolution in enumerate(resolutions):
        download_gif_path = "download-ezgif.com-resize.gif"
        download_gif = Image.open(download_gif_path)
        download_frames = [ImageTk.PhotoImage(frame.copy()) for frame in ImageSequence.Iterator(download_gif)]

        download_btn = Button(highlightthickness=0)
        download_btn.grid(row=5 + i*2, column=2, padx=10, pady=5)
        widgets_created.append(download_btn)

        def animate_download(btn, frame_index=0):
            frame_index = (frame_index + 1) % len(download_frames)
            btn.config(image=download_frames[frame_index])
            btn.after(100, animate_download, btn, frame_index)

        animate_download(download_btn)
        download_btn.bind("<Button-1>", lambda event, res=resolution: select_type(res))

def audio_download():
    clear_widgets()
    quality_label = tk.Label(text="Choose Quality", bg=BG, fg="coral", font=("Times 20 italic bold", 20))
    quality_label.grid(row=4, column=1)
    widgets_created.append(quality_label)

    streams = yt.streams.filter(adaptive=True)
    video_streams.clear()
    streams_list.clear()
    audio_streams.clear()
    qualities.clear()
    resolutions.clear()

    for stream in streams:
        x = str(stream).replace("<", "(").replace(">", ")")
        streams_list.append(x)

    for stream in streams_list:
        if "audio/webm" in stream:
            audio_streams.append(stream)
    pattern = r'abr="(\d+kbps)"'

    for stream in audio_streams:
        match = re.search(pattern, stream)
        if match:
            qualities.append(match.group(1))
    gif_path = "music-ezgif.com-resize.gif"
    gif = Image.open(gif_path)
    frames = [ImageTk.PhotoImage(frame.copy()) for frame in ImageSequence.Iterator(gif)]

    for i, quality in enumerate(qualities):
        audio_quality_btn = tk.Label(bg=BG)
        audio_quality_btn.grid(row=5 + i*2, column=0, padx=10, pady=5)
        widgets_created.append(audio_quality_btn)

        def animate(btn, frame_index=0):
            frame_index = (frame_index + 1) % len(frames)
            btn.config(image=frames[frame_index])
            btn.after(100, animate, btn, frame_index)

        animate(audio_quality_btn)

        audio_quality_label = tk.Label(text=f"Download {qualities[i]}", bg=BG, fg="green", font=("Times 20 italic bold", 10))
        audio_quality_label.grid(row=5 + i*2, column=1, padx=10, pady=5)
        widgets_created.append(audio_quality_label)
        audio_quality_btn.bind("<Button-1>", lambda event, abr=quality: select_type(abr))

    for i, quality in enumerate(qualities):
        download_gif_path = "download-ezgif.com-resize.gif"
        download_gif = Image.open(download_gif_path)
        download_frames = [ImageTk.PhotoImage(frame.copy()) for frame in ImageSequence.Iterator(download_gif)]

        download_btn = Button(highlightthickness=0)
        download_btn.grid(row=5 + i*2, column=2, padx=10, pady=5)
        widgets_created.append(download_btn)

        def animate_download(btn, frame_index=0):
            frame_index = (frame_index + 1) % len(download_frames)
            btn.config(image=download_frames[frame_index])
            btn.after(100, animate_download, btn, frame_index)

        animate_download(download_btn)
        download_btn.bind("<Button-1>", lambda event, abr=quality: select_type(abr))

def downloader(video, audio):
    stream2 = yt.streams.get_by_itag(video)
    output_text.delete(1.0, tk.END)
    output_text.insert(tk.END, "Downloading...\n")
    video_f = stream2.download("downloads/")
    stream = yt.streams.get_by_itag(audio)
    audio_f = stream.download("outputs/")


    video_path = f'{video_f}'
    audio_path = f'{audio_f}'

    video_clip = VideoFileClip(video_path)
    audio_clip = AudioFileClip(audio_path)
    video_clip = video_clip.set_audio(audio_clip)

    try:
        output_path = f'downloads/{yt.title} ({stream2.resolution}).mp4'
        video_clip.write_videofile(output_path)
        output_text.insert(tk.END, "Download completed successfully!\n")
        tuturu()
        play_sound()
        video_clip.close()
        try:
            os.remove(video_f)
            os.remove(audio_f)
        except:
            pass
    except Exception as e:
        pass


def animate_gif(label, gif_frames, frame_num):
    frame = gif_frames[frame_num]
    photo = ImageTk.PhotoImage(frame)
    label.configure(image=photo)
    label.image = photo
    frame_num = (frame_num + 1) % len(gif_frames)
    label.after(50, animate_gif, label, gif_frames, frame_num)

def tuturu():
    tutu_messagebox = tk.Toplevel()
    tutu_messagebox.title("Message")

    gif_path = "Tuturu-ezgif.com-resize.gif"
    if os.path.exists(gif_path):
        gif = Image.open(gif_path)
        gif_frames = [frame.copy() for frame in ImageSequence.Iterator(gif)]

        gif_label = tk.Label(tutu_messagebox)
        gif_label.pack()
        animate_gif(gif_label, gif_frames, 0)
    else:
        print("Error: GIF file not found.")

    message_label = tk.Label(tutu_messagebox, text="Download Completed!")
    message_label.pack()
    close_button = tk.Button(tutu_messagebox, text="Close", command=tutu_messagebox.destroy)
    close_button.pack()

def play_sound():
    pygame.mixer.init()
    sound_path = "tuturu_1.mp3"
    if os.path.exists(sound_path):
        pygame.mixer.music.load(sound_path)
        pygame.mixer.music.play()
    else:
        print("Error: Sound file not found.")


def search_is_empty():
    message_box = tk.Toplevel()
    message_box.title("Hold On!")

    image_path = "search not found.jpg"
    if os.path.exists(image_path):
        image = Image.open(image_path)
        photo = ImageTk.PhotoImage(image)
        image_label = tk.Label(message_box, image=photo)
        image_label.photo = photo
        image_label.pack()
    else:
        print("Error: Image file not found.")

    message_label = tk.Label(message_box, text="You can't search without a URL!",fg="darkred")
    message_label.pack()

    close_button = tk.Button(message_box, text="Close", command=message_box.destroy)
    close_button.pack()


def clear_widgets():
    for widget in widgets_created:
        widget.grid_forget()
        widget.destroy()
    widgets_created.clear()

######################################UI############################################

window = tk.Tk()
window.config(width=800, height=1000, padx=20, pady=20, bg=BG)

link_label = tk.Label(text="Youtube Video Link:", font=("Times 20 italic bold", 15), bg=BG)
link_label.grid(row=0, column=0, padx=10)

link_entry = tk.Entry(textvariable="Link Here...", width=50, fg="red")
link_entry.grid(row=0, column=1)

canvas = tk.Canvas(width=500, height=300)
canvas.config(bg=BG, highlightthickness=0, borderwidth=0)
canvas_text = canvas.create_text(100, 50, text="", fill="darkblue", font=("Times 20 italic bold", 11), anchor='center', width=350)
author_text = canvas.create_text(100, 50, text="", fill="darkblue", font=("Times 20 italic bold", 11), anchor='center')

initial_img = ImageTk.PhotoImage(Image.new('RGB', (50, 50), (255, 255, 255)))
canvas.itemconfig(initial_img, state='hidden')
panel_image = canvas.create_image(25, 25)
canvas.grid(row=1, column=0, columnspan=3)

search_img = tk.PhotoImage(file="find.png")
get_btn = tk.Button(image=search_img, command=get_info_thread, highlightthickness=0, bg=BG, borderwidth=0)
get_btn.grid(row=0, column=2, padx=20)

download_vid_label = tk.Label(text="Download Video", bg=BG, font=("Times 20 italic bold", 10), anchor='center')
download_vid_label.grid(row=2, column=0)
vid_img = tk.PhotoImage(file="movie.png")
download_vid_btn = tk.Button(image=vid_img, highlightthickness=0, borderwidth=0, bg=BG, command=video_download_thread)
download_vid_btn.grid(row=3, column=0)

download_audio_label = tk.Label(text="Download Mp3", bg=BG, font=("Times 20 italic bold", 10), anchor='center')
download_audio_label.grid(row=2, column=2)
audio_img = tk.PhotoImage(file="download.png")
download_audio_btn = tk.Button(image=audio_img, highlightthickness=0, borderwidth=0, bg=BG, command=audio_download_thread)
download_audio_btn.grid(row=3, column=2)

output_text = scrolledtext.ScrolledText(window, width=33, height=0)
output_text.grid(row=3,column=1)

m = tk.Menu(window, tearoff=0)
m.add_command(label="Paste", command=paste_text)

link_entry.bind("<Button-3>", lambda e: m.tk_popup(e.x_root, e.y_root))
link_entry.bind("<FocusIn>", lambda e: m.unpost())

window.mainloop()
